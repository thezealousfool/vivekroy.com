import math

import matplotlib.pyplot as plt
import numpy as np

from scipy.interpolate import BSpline, splrep, CubicSpline

from scipy.optimize import minimize


# parameter
MAX_T = 100.0  # maximum time to the goal [s]
MIN_T = 5.0  # minimum time to the goal[s]

show_animation = True


class Curve(object):
  def __init__(self, p0, p1, t0, t1, r_min):
    self.p0 = p0  # starting position
    self.p1 = p1  # goal position
    self.t0 = t0 / np.linalg.norm(t0)   # starting yaw angle
    self.t1 = t1 / np.linalg.norm(t1)   # goal yaw angle
    self.r_min = r_min    # minimum turning radius

    self.m0 = 3   # magnitude of starting tangential vector(velocity), (the same as yaw angle), (will be optimized in the self.optimize function)
    self.m1 = 1   # magnitude of goal tangential vector(velocity)
    self.len = -1   # length of the curve, will be computed in self.reparameterization
    self.parameterize()
    self.reparameterize()

  def parameterize(self):
    # parameterize the curve with CubicSpline, w.r.t. t 
    self.cx = CubicSpline(np.array([0,1]), np.array([p0[0], p1[0]]), bc_type=( (1, t0[0] * self.m0 ), (1, t1[0] * self.m1 ) ))
    self.cy = CubicSpline(np.array([0,1]), np.array([p0[1], p1[1]]), bc_type=( (1, t0[1] * self.m0 ), (1, t1[1] * self.m1 ) ))

  def reparameterize(self):
    # reparameterize to curve w.r.t. arc length s (equal distance)
    n_dt = 4000
    ts = np.linspace(0, 1, n_dt)
    dt = 1.0 / (n_dt - 1)
    x1 = self.cx.derivative(1)(ts)
    y1 = self.cy.derivative(1)(ts)
    L = np.sqrt(x1 * x1 + y1 * y1) * dt

    ss = []
    for i in np.arange(0, n_dt):
      ss.append(np.sum(L[0:i+1]))   # integrate arc length s w.r.t. t

    t,c,k = splrep(ss, ts)
    ts = BSpline(t,c,k)   # get s -> t

    s = np.linspace(0, ss[-1], 10000)
    t = ts(s)
    x = self.cx(t)
    y = self.cy(t)

    t,c,k = splrep(s, x)
    self.cx = BSpline(t,c,k)    # get s -> x
    t,c,k = splrep(s,y)
    self.cy = BSpline(t,c,k)    # get s -> y
    self.len = ss[-1]           # length of the curve

  def t_parameterize(self):
    n_s = 1000
    ss = np.linspace(0, self.len, n_s)
    ds = self.len / (n_s - 1)
    t = 0
    ts = []

    vs = self.v(ss)
    xs = self.cx(ss)
    ys = self.cy(ss)
    dts = 1.0 / vs * ds
    for i,s in enumerate(ss):
      ts.append(np.sum(dts[:i])+1)
    self.len = ts[-1]

    t,c,k = splrep(ts, ss)
    self.st = BSpline(t,c,k)

    t,c,k = splrep(ts, xs)
    self.cx = BSpline(t,c,k)

    t,c,k = splrep(ts, ys)
    self.cy = BSpline(t,c,k)


  def p(self, s):
    # s -> position
    res = np.hstack( [self.cx(s).reshape(-1,1), self.cy(s).reshape(-1,1)] )
    res = res[0] if res.shape[0] == 1 else res
    return res

  def tangential(self, s):
    # s -> tangential, (magnitude of it is velocity)
    res =  np.hstack( [self.cx.derivative(1)(s).reshape(-1,1), self.cy.derivative(1)(s).reshape(-1,1)])
    res = res[0] if res.shape[0] == 1 else res
    return res

  def normal(self, s):
    # s -> normal vector, (magnitude of it is curvature k, if speed is constant)
    res = np.hstack( [self.cx.derivative(2)(s).reshape(-1,1), self.cy.derivative(2)(s).reshape(-1,1)])  
    res = res[0] if res.shape[0] == 1 else res
    return res

  def v(self, s):
    tangentials = self.tangential(s)
    res = np.hypot(tangentials[:,0], tangentials[:,1])
    res = res[0] if res.shape[0] == 1 else res
    return res

  def k(self, s):
    normal = self.normal(s)
    res = np.hypot(normal[:,0], normal[:,1])
    res = res[0] if res.shape[0] == 1 else res
    return res

  def r(self, s):
    res = 1.0 / np.abs(self.k(s))
    res = res[0] if res.shape[0] == 1 else res
    return res

  def loss(self, ms):
    # loss function, minimize the curve length
    self.m0 = ms[0]
    self.m1 = ms[1]
    self.parameterize()
    self.reparameterize()
    # print('len:', self.len)

    return self.len

  def radius_cons(self, ms):
    # inequivalent constraint for turning radius
    self.m0 = ms[0]
    self.m1 = ms[1]
    self.parameterize()
    self.reparameterize()

    ss = np.linspace(0, self.len, 200)
    rs = self.r(ss)
    d = np.min(rs) - (self.r_min * 1.1)
    # print(np.min(rs) - self.r_min)
    return d

  def optimize(self):
    # optimize m0 and m1
    cons =({
      'type': 'ineq',
      'fun': self.radius_cons
      })
    res = minimize(self.loss, [self.m0, self.m1], method='SLSQP', constraints=cons, options={'disp': True})

    self.m0, self.m1 = res.x
    self.parameterize()
    self.reparameterize()


class Planner(object):

    def __init__(self, sx, sy, syaw, sv, sa, gx, gy, gyaw, gv, ga, max_accel, max_jerk, max_steer, dt, L, min_t=MIN_T, max_t=MAX_T):
        self.set_param(sx, sy, syaw, sv, sa, gx, gy, gyaw, gv, ga, max_accel, max_jerk, max_steer, dt, L, min_t, max_t)
        self.curve = Curve(np.array([sx,sy]), np.array([gx,gy]), np.array([np.cos(syaw), np.sin(syaw)]), np.array([np.cos(gyaw), np.sin(gyaw)]), 0.67 )
        

    def set_param(self, sx, sy, syaw, sv, sa, gx, gy, gyaw, gv, ga, max_accel, max_jerk, max_steer, dt, L, min_t=MIN_T, max_t=MAX_T):
        self.sx = sx  # start x position [m]
        self.sy = sy  # start y position [m]
        self.syaw = syaw  # start yaw angle [rad]
        self.sv = sv  # start speed [m/s]
        self.sa = sa  # start accel [m/ss]
        self.gx = gx  # goal x position [m]
        self.gy = gy  # goal y position [m]
        self.gyaw = gyaw  # goal yaw angle [rad]
        self.gv = gv  # goal speed [m/s]
        self.ga = ga  # goal accel [m/ss]
        self.max_accel = max_accel  # max accel [m/ss]
        self.max_jerk = max_jerk  # max jerk [m/sss]
        self.max_steer = max_steer
        self.dt = dt  # time tick [s]
        self.L = L
        self.min_t = min_t
        self.max_t = max_t
        self.max_k = 1 / 0.67
        self.t_max = 80


    def plan2(self, show_animation=False):
        sx = self.sx  # start x position [m]
        sy = self.sy  # start y position [m]
        syaw = self.syaw  # start yaw angle [rad]
        sv = self.sv  # start speed [m/s]
        sa = self.sa  # start accel [m/ss]
        gx = self.gx  # goal x position [m]
        gy = self.gy  # goal y position [m]
        gyaw = self.gyaw  # goal yaw angle [rad]
        gv = self.gv  # goal speed [m/s]
        ga = self.ga  # goal accel [m/ss]
        max_accel = self.max_accel  # max accel [m/ss]
        max_jerk = self.max_jerk  # max jerk [m/sss]
        max_steer = self.max_steer
        dt = self.dt  # time tick [s]
        min_t = self.min_t
        max_t = self.max_t
        self.p0 = np.array( [sx, sy] )
        self.p1 = np.array( [gx, gy] )
        self.t0 = np.array( [math.cos(syaw), math.sin(syaw)] )
        self.t1 = np.array( [math.cos(gyaw), math.sin(gyaw)] )

        res = minimize(self.criteria, [1e-3, 1e-3], method='Nelder-Mead')
        print(res)
        m0 = res.x[0]
        m1 = res.x[1]
        self.t0 *= m0
        self.t1 *= m1

        np.set_printoptions(precision=2)
        print('p0', self.p0)
        print('p1', self.p1)
        print('t0', self.t0)
        print('t1', self.t1)
        print('m0', m0, 'm1', m1)

        self.rx = CubicSpline(np.array([0,self.t_max]), np.array([self.p0[0], self.p1[0]]), bc_type=( (1, self.t0[0] *m0), (1, self.t1[0]*m1) ))
        self.ry = CubicSpline(np.array([0,self.t_max]), np.array([self.p0[1], self.p1[1]]), bc_type=( (1, self.t0[1] *m0), (1, self.t1[1]*m1) ))

        self.t = np.arange(0, self.t_max + self.dt, self.dt)
        self.x = self.rx(self.t)
        self.y = self.ry(self.t)
        self.v = np.hypot(self.rx.derivative(1)(self.t), self.ry.derivative(1)(self.t))
        self.yaw = np.arctan2(self.y, self.x)
        self.s = (self.yaw[1:] - self.yaw[:-1]) / self.dt * self.L / self.v[:-1]
        self.s = np.append(self.s, self.s[-1])
        self.a = np.hypot(self.rx.derivative(2)(self.t), self.ry.derivative(2)(self.t))

        self._compute_spline()

        if show_animation:  # pragma: no cover
            self.show_animation()

    def get_k(self, cx, cy, t):
      x1 = cx.derivative(1)(t)
      x2 = cx.derivative(2)(t)
      y1 = cy.derivative(1)(t)
      y2 = cy.derivative(2)(t)

      k = (x1 * y2 - y1 * x2) / (x1**2 + y1**2) **1.5
      return k

    def get_k_vec(self, cx, cy, t):
      x1 = cx.derivative(1)(t)
      x2 = cx.derivative(2)(t)
      y1 = cy.derivative(1)(t)
      y2 = cy.derivative(2)(t)

      k = np.abs( ( x1 * y2 - y1 * x2 ) / np.power( x1 * x1 + y1 * y1 , 1.5) )
      return k

    def get_t_max_curvature_num(self, cx, cy):
      nMax = 100
      ts = []
      kMax = -1e8
      t = np.linspace(0, self.t_max, nMax)
      k = self.get_k_vec(cx, cy, t)
      # print(np.max(k))
      return np.max(k)


    def criteria(self, ms):
      m0 = ms[0]
      m1 = ms[1]

      cx = CubicSpline(np.array([0,self.t_max]), np.array([self.p0[0], self.p1[0]]), bc_type=( (1, self.t0[0] *m0), (1, self.t1[0]*m1) ))
      cy = CubicSpline(np.array([0,self.t_max]), np.array([self.p0[1], self.p1[1]]), bc_type=( (1, self.t0[1] *m0), (1, self.t1[1]*m1) ))

      kMax = self.get_t_max_curvature_num(cx, cy)
      return np.abs(kMax - self.max_k * 0.9)

    def _compute_steering_angle(self):
        # v = self.v[:-1]
        # theta = np.arctan( (self.yaw[1:] - self.yaw[:-1]) / self.dt * self.L / v )
        # self.s = np.append(theta, theta[-1])

        sv = (self.s[1:] - self.s[:-1]) / self.dt
        self.sv = np.append(sv, sv[-1])

    def _compute_spline(self):
        t,c,k = splrep(self.t, self.x)
        self.x = BSpline(t,c,k)

        t,c,k = splrep(self.t, self.y)
        self.y = BSpline(t,c,k)

        t,c,k = splrep(self.t, self.yaw)
        self.yaw = BSpline(t,c,k)

        t,c,k = splrep(self.t, self.v)
        self.v = BSpline(t,c,k)

        t,c,k = splrep(self.t, self.a)
        self.a = BSpline(t,c,k)

        t,c,k = splrep(self.t, self.s)
        self.s = BSpline(t,c,k)


    def show_animation(self):
        mode = 1

        if mode == 0:
            for i, t in enumerate(self.t):
                plt.cla()
                # for stopping simulation with the esc key.
                plt.gcf().canvas.mpl_connect('key_release_event',
                                             lambda event: [exit(0) if event.key == 'escape' else None])
                plt.grid(True)
                plt.axis("equal")
                plot_arrow(self.sx, self.sy, self.syaw)
                plot_arrow(self.gx, self.gy, self.gyaw)
                plot_arrow(self.x(t), self.y(t), self.yaw(t))
                plt.title("Time[s]:" + str(t)[0:4] +
                          " v[m/s]:" + str(self.v(t))[0:4] +
                          " a[m/ss]:" + str(self.a(t))[0:4] +
                          " steer[rad]:" + str(self.s(t))[0:4],
                          )
                plt.pause(0.00001)
        elif mode == 1:
            plt.cla()
            # for stopping simulation with the esc key.
            plt.gcf().canvas.mpl_connect('key_release_event',
                                         lambda event: [exit(0) if event.key == 'escape' else None])
            plt.grid(True)
            plt.axis("equal")
            x = self.x(self.t)
            y = self.y(self.t)
            plt.plot(x,y)
            plt.show()


class Polynomial(object):

    def __init__(self, xs, vxs, axs, xe, vxe, axe, time):
        self.a0 = xs
        self.a1 = vxs
        self.a2 = axs / 2.0

        A = np.array([[time ** 3, time ** 4, time ** 5],
                      [3 * time ** 2, 4 * time ** 3, 5 * time ** 4],
                      [6 * time, 12 * time ** 2, 20 * time ** 3]])
        b = np.array([xe - self.a0 - self.a1 * time - self.a2 * time ** 2,
                      vxe - self.a1 - 2 * self.a2 * time,
                      axe - 2 * self.a2])
        x = np.linalg.solve(A, b)

        self.a3 = x[0]
        self.a4 = x[1]
        self.a5 = x[2]

    def calc_point(self, t):
        xt = self.a0 + self.a1 * t + self.a2 * t ** 2 + \
             self.a3 * t ** 3 + self.a4 * t ** 4 + self.a5 * t ** 5

        return xt

    def calc_first_derivative(self, t):
        xt = self.a1 + 2 * self.a2 * t + \
             3 * self.a3 * t ** 2 + 4 * self.a4 * t ** 3 + 5 * self.a5 * t ** 4

        return xt

    def calc_second_derivative(self, t):
        xt = 2 * self.a2 + 6 * self.a3 * t + 12 * self.a4 * t ** 2 + 20 * self.a5 * t ** 3

        return xt

    def calc_third_derivative(self, t):
        xt = 6 * self.a3 + 24 * self.a4 * t + 60 * self.a5 * t ** 2

        return xt

def plot_arrow(x, y, yaw, length=1.0, width=0.5, fc="r", ec="k"): 
    plt.arrow(x, y, length * math.cos(yaw), length * math.sin(yaw),
              fc=fc, ec=ec, head_width=width, head_length=width)
    plt.plot(x, y)


def main():
    print(__file__ + " start!!")

    sx = 10.0  # start x position [m]
    sy = 10.0  # start y position [m]
    syaw = np.deg2rad(10.0)  # start yaw angle [rad]
    sv = 1.0  # start speed [m/s]
    sa = 0.1  # start accel [m/ss]
    gx = 30.0  # goal x position [m]
    gy = -10.0  # goal y position [m]
    gyaw = np.deg2rad(90.0)  # goal yaw angle [rad]
    gv = 1.0  # goal speed [m/s]
    ga = 0.1  # goal accel [m/ss]
    max_accel = 3.0  # max accel [m/ss]
    max_jerk = 0.5  # max jerk [m/sss]
    max_steer = 1.5
    max_yaw = 0.5
    dt = 0.1  # time tick [s]
    L = 0.335

    p = Planner(
        sx, sy, syaw, sv, sa, gx, gy, gyaw, gv, ga, max_accel, max_jerk, max_steer, dt, L)

    p.plan(1)


if __name__ == '__main__':
    main()