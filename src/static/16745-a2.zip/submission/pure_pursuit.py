#!/usr/bin/env python

from common import *
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseArray, Pose, Twist
from ackermann_msgs.msg import AckermannDriveStamped
from angles import *
import tf

import numpy as np
from planner import Planner

def waypointCallback(msg):
  global waypoints
  for i in range(len(msg.poses)):
    waypoints[i, 0] = msg.poses[i].position.x
    waypoints[i, 1] = msg.poses[i].position.y
    waypoints[i, 2] = euler_from_quaternion([msg.poses[i].orientation.x, msg.poses[i].orientation.y, msg.poses[i].orientation.z, msg.poses[i].orientation.w])[2]

def vehicleStateCallback(msg):
  global rear_axle_center, rear_axle_theta, rear_axle_velocity
  rear_axle_center.position.x = msg.pose.pose.position.x
  rear_axle_center.position.y = msg.pose.pose.position.y
  rear_axle_center.orientation = msg.pose.pose.orientation

  rear_axle_theta = euler_from_quaternion(
    [rear_axle_center.orientation.x, rear_axle_center.orientation.y, rear_axle_center.orientation.z,
     rear_axle_center.orientation.w])[2]

  rear_axle_velocity.linear = msg.twist.twist.linear
  rear_axle_velocity.angular = msg.twist.twist.angular

def pursuit(waypoint):
  print('Next point:', waypoint)
  global rear_axle_center, rear_axle_theta, rear_axle_velocity, cmd_pub

  L = 0.335

  gx = waypoint[0]
  gy = waypoint[1]
  gyaw = waypoint[2]
  gv = 0
  ga = 0
  max_accel = max_acc
  max_jerk = 1e8
  max_steer = 0.5
  dt = 0.1

  rospy.wait_for_message("/ackermann_vehicle/ground_truth/state", Odometry, 5)
  x = sx = rear_axle_center.position.x
  y = sy = rear_axle_center.position.y
  syaw = rear_axle_theta
  sv = np.linalg.norm( np.array([rear_axle_velocity.linear.x,  rear_axle_velocity.linear.y]))
  sa = 0
  p = Planner(sx, sy, syaw, sv, sa, gx, gy, gyaw, gv, ga, max_accel, max_jerk, max_steer, dt, L)
  p.plan2(1)
  t0 = rospy.Time.now()

  target_distance = math.sqrt( (x - gx)**2 + (y - gy)**2 )  

  while True:
    rospy.wait_for_message("/ackermann_vehicle/ground_truth/state", Odometry, 5)
    t = (rospy.Time.now() - t0).to_sec()
    x = rear_axle_center.position.x
    y = rear_axle_center.position.y
    yaw = rear_axle_theta
    v = np.linalg.norm( np.array([rear_axle_velocity.linear.x,  rear_axle_velocity.linear.y]))
    a = 0

    target_distance = math.sqrt( (x - gx)**2 + (y - gy)**2 )  
    if target_distance <= waypoint_tol:
      break

    deviation = math.sqrt( (x - p.x(t))**2 + (y - p.y(t))**2 )
    if deviation > waypoint_tol * 5:
      print('Deviated, replanning...', waypoint)
      p = Planner(x, y, yaw, v, a, gx, gy, gyaw, gv, ga, max_accel, max_jerk, max_steer, dt, L)
      p.plan2(1)
      t0 = rospy.Time.now()
      print('Replanned')

    cmd = AckermannDriveStamped()
    cmd.header.frame_id = "base_link"
    cmd.header.stamp = rospy.Time.now()
    cmd.drive.speed = p.v(t)
    cmd.drive.acceleration = p.a(t)
    cmd.drive.steering_angle = p.s(t)


    np.set_printoptions(precision=2)
    print('x,y', p.x(t), p.y(t) )
    # print('v,a', p.v(t), p.a(t) )
    print('s', p.s(t))
    print(' ')
    # cmd.drive.steering_angle_velocity = p.sv(t)
    cmd_pub.publish(cmd)


if __name__ == '__main__':

  rospy.init_node('pure_pursuit')
  cmd_pub = rospy.Publisher('/ackermann_vehicle/ackermann_cmd', AckermannDriveStamped, queue_size=10)

  waypoints = np.zeros((num_waypoints, 3))
  rospy.Subscriber("/ackermann_vehicle/waypoints",
                   PoseArray,
                   waypointCallback)
  rospy.wait_for_message("/ackermann_vehicle/waypoints", PoseArray, 5)


  rear_axle_center = Pose()
  rear_axle_velocity = Twist()
  rospy.Subscriber("/ackermann_vehicle/ground_truth/state",
                   Odometry, vehicleStateCallback)
  rospy.wait_for_message("/ackermann_vehicle/ground_truth/state", Odometry, 5)

  for w in waypoints:
    # pursuitToWaypoint(w)
    pursuit(w)




