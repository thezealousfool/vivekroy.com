
function [r, p, y] = part4( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )

global link_length relative_angles target obstacles lb ub R_target;

quat_target = target(4:7).';
R_target = quat2rotm(quat_target);

lb = [min_roll, min_pitch, min_yaw];
ub = [max_roll, max_pitch, max_yaw];

num_answers = 15;

%% run without gradient
initdraw
options = optimset('MaxFunEvals',1000000,'Algorithm','sqp');

anwers = zeros(num_answers, 3 * size(link_length, 1));
for i = 1 : num_answers
    relative_angles = zeros(size(link_length,1), 3);
    for j = 1 : size(link_length, 1)
        roll = rand() * (max_roll(j) - min_roll(j))  + min_roll(j);
        pitch = rand() * (max_pitch(j) - min_pitch(j)) + min_pitch(j);
        yaw = rand() * (max_yaw(j) - min_yaw(j)) + min_yaw(j);
        relative_angles(j , :) = [roll, pitch, yaw];
    end
    relative_angles = relative_angles(:).';
    
    [answer,fval,exitflag]=fmincon(@pure_criterion, relative_angles, [],[],[],[],lb,ub,@constraints,options); 
    answers(i, :) = answer(:);
    disp('searching different solutions: ');
    disp(i / num_answers)
end

% find the most different(non-trivial) answers
k = 1;
for i = 1 : num_answers
    for j = i : num_answers
        dis = norm(answers(i,:) - answers(j,:));
        distances(k, 1) = dis;
        distances(k, 2) = i;
        distances(k, 3) = j;
        k = k+1;
    end
end
distances = sortrows(distances, 1, 'descend');
answers_best = zeros(3, 3 * size(link_length,1));
answers_best(1,:) = answers(distances(1,2),:);
answers_best(2,:) = answers(distances(1,3),:);
if (distances(2,2) ~= distances (1,2) && distances(2,2) ~= distances(1,3))
    answers_best(3,:) = answers(distances(2,2),:);
else
    answers_best(3,:) = answers(distances(2,3),:);
end


update_draw( reshape( answers_best(1,:), [], 3)  );
w = 0;
while w ~= 1
    w = waitforbuttonpress;
end
update_draw( reshape( answers_best(2,:), [], 3)  );
w = 0;
while w ~= 1
    w = waitforbuttonpress;
end
update_draw( reshape( answers_best(3,:), [], 3)  );

a = reshape( answers_best(1,:), [], 3);
b = reshape( answers_best(2,:), [], 3);
c = reshape( answers_best(3,:), [], 3);

r = a(:, 1);
p = a(:, 2);
y = a(:, 3);

end
