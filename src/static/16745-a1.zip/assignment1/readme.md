## Assignment1 of 16745
### Team:
Jianzhe GU
Vivek Roy
Yiwei Lyu

### Quick Start

#### part 1
go to part1 folder, type
```
[r, p, y] = part1( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )
```	

#### part 2
go to part2 folder, type
```
[r, p, y] = part2( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )
```

#### part 3
go to part3 folder, type
```
[r, p, y] = part3( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles, method )
```
The last parameter 'method' can be "sqp", "interior-point", "active-set", "trust-region-reflective" and "cmaes".

#### part 4
go to part4 folder, type
```
 [r, p, y] = part4( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )
```
There will be by default 3 different solutions showing up sequentially. Press "w" to show the next solution.
