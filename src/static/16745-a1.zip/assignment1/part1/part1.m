function [r, p, y] = part1( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles )
digits(5);
global link_length relative_angles target obstacles lb ub R_target grad ra;

quat_target = target(4:7).';
R_target = quat2rotm(quat_target);

lb = [min_roll, min_pitch, min_yaw];
ub = [max_roll, max_pitch, max_yaw];

%% run with gradient

initdraw

relative_angles = zeros(size(link_length,1), 3);
for j = 1 : size(link_length, 1)
    roll = rand() * (max_roll(j) - min_roll(j))  + min_roll(j);
    pitch = rand() * (max_pitch(j) - min_pitch(j)) + min_pitch(j);
    yaw = rand() * (max_yaw(j) - min_yaw(j)) + min_yaw(j);
    relative_angles(j , :) = [roll, pitch, yaw];
end
relative_angles = relative_angles(:).';

options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');
[answer,fval,exitflag]=fmincon(@criterion, relative_angles, [],[],[],[],lb,ub,@constraints,options);

update_draw(answer);

a = reshape(answer, [], 3);
r = a(:, 1);
p = a(:, 2);
y = a(:, 3);

end