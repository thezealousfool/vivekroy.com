clear; clear global; close all; clc;

link_length = [0.2, 0.5, 0.3]';     



target = [0.5, 0.5, 0.5, 1, 0, 0, 0]';

obstacles = [
    0.5376    0.8385   -0.0893  0.1
   -0.0483   -0.0153    0.5026  0.1
   -0.0145    0.4413    0.3018  0.1
    0.3330   -0.0576    0.7001  0.1
    0.2580    0.4093    0.8625  0.1
    0.3700    0.3922    0.3426  0.1
    0.2920    0.5114    0.0548  0.1
];

min_roll = [-pi/2, -pi, -pi]';
max_roll = [pi/2, pi, pi]';
min_pitch =  [-pi/2, -pi, -pi]';
max_pitch = [pi/2, pi, pi]';
min_yaw =  [-pi/2, -pi, -pi]';
max_yaw =[pi/2, pi, pi]';


link_length = [0.3, 0.6, 0.3]';     


min_roll = [-pi/2, -pi, -pi]';
max_roll = [pi/2, pi, pi]';
min_pitch =  [-pi/2, -pi, -pi]';
max_pitch = [pi/2, pi, pi]';
min_yaw =  [-pi/2, -pi, -pi]';
max_yaw =[pi/2, pi, pi]';




link_length = [0.2, 0.5, 0.3, 0.2, 0.2]';     


min_roll = [-pi/2, -pi, -pi, -pi,-pi]';
max_roll = [pi/2, pi, pi, pi,pi]';
min_pitch =  [-pi/2, -pi, -pi, -pi,-pi]';
max_pitch = [pi/2, pi, pi, pi,pi]';
min_yaw =  [-pi/2, -pi, -pi, -pi,-pi]';
max_yaw =[pi/2, pi, pi, pi,pi]';

% 
% link_length = [0.2, 0.5, 0.3, 0.2, 0.2, 0.2, 0.2]';     
% 
% 
% min_roll = [-pi/2, -pi, -pi, -pi,-pi, -pi,-pi]';
% max_roll = [pi/2, pi, pi, pi,pi, pi,pi]';
% min_pitch =  [-pi/2, -pi, -pi, -pi,-pi, -pi,-pi]';
% max_pitch = [pi/2, pi, pi, pi,pi, pi,pi]';
% min_yaw =  [-pi/2, -pi, -pi, -pi,-pi, -pi,-pi]';
% max_yaw =[pi/2, pi, pi, pi,pi, pi,pi]';
% 
% 
% 




relative_angles = zeros(size(link_length,1), 3);