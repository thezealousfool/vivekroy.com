function a = update_draw(relative_angles)
    global link_length ls

    % update the position of joints
    ps = fk(relative_angles);
    for i = 1 : size(link_length, 1)
        set(ls(i),'Xdata', [ps(i, 1), ps(i+1, 1)]);
        set(ls(i),'Ydata', [ps(i, 2), ps(i+1, 2)]);
        set(ls(i),'Zdata', [ps(i, 3), ps(i+1, 3)]);

        hold on
    end

    axis([-0.5, 1.2, -0.5, 1.2, -0.5, 1.2]);        % fix 3D viewport
    
end
