global link_length target obstacles relative_angles
global ls os t ax

scrsz = get(0,'ScreenSize');        % get screen size, not used

% create figure
fig = figure(1);
fig.Name = 'task 1';
fig.Position = [20, 100, 500, 500];

% create axis
ax = axes('Parent', fig, 'Units', 'Pixels');
ax.Position = [0, 0, 500, 500];

% draw target
[x_sphere, y_sphere, z_sphere] = sphere;
r = 0.01;
t = surf(x_sphere * r + target(1), y_sphere * r + target(2), z_sphere * r + target(3), zeros(size(z_sphere)), 'Parent', ax);
colormap summer
shading interp
hold on

unit_vec = [ 1, 0, 0];
r = quat2rotm(target(4:7)');
p_q = r .* unit_vec .* 0.2;
x0 = target(1);
x1 = target(1) - p_q(1);
y0 = target(2);
y1 = target(2) - p_q(2);
z0 = target(3);
z1 = target(3) - p_q(3);
line( [x0, x1], [y0, y1], [z0, z1]);
hold on

% draw obstacles
os = [];
for i = 1 : size(obstacles, 1)
    r = obstacles(i, 4);
    x = obstacles(i, 1);
    y = obstacles(i, 2);
    z = obstacles(i, 3);
    
    [x_sphere, y_sphere, z_sphere] = sphere;
    
    os(i) = surf(x_sphere * r + x, y_sphere * r + y, z_sphere * r + z, zeros(size(z_sphere)), 'Parent', ax);
  
    hold on
end

% create lines, will update in update_draw.m
ls = [];
for i = 1 : size(link_length, 1)
    ls(i) = line('Parent', ax, 'LineWidth', 4);
end
