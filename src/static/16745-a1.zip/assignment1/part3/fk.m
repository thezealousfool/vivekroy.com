function [ps, R] = fk(relative_angles)
    global link_length;
    
    row = [1, 0, 0]';
    p = [0, 0, 0]';
    R = eye(size(3, 1));
    
    relative_angles = reshape(relative_angles, [], 3);
    
    for i = 1 : size(relative_angles, 1)
        y = relative_angles(i, 1);  % row
        b = relative_angles(i, 2); % pitch
        a = relative_angles(i, 3); % yaw
%         relative_R = eul2rotm([y, b, a], 'XYZ');
        relative_R = euler2rotm(a, b, y);
    
        R = R * relative_R;     % accumulated global rotation matrix of the joint
        p = p + R * row .* link_length(i);      % accumulated joint position
        ps(i, :) = p;
    end
    
    ps = [zeros(1, 3) ; ps];       % append [0,0,0] as the first joint
    
end


function rotm = euler2rotm(a, b, y)
    rotm = [
    cos(a) * cos(b),  cos(a) * sin(b) * sin(y) - sin(a) * cos(y), cos(a) * sin(b) * cos(y) + sin(a) * sin(y);
    sin(a) * cos(b), sin(a)*sin(b)*sin(y)+cos(a) * cos(y), sin(a) * sin(b) * cos(y) - cos(a) * sin(y);
    -sin(b), cos(b)*sin(y), cos(b)*cos(y)
    ];
end