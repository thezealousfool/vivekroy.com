function [r, p, y] = part3( target, link_length, min_roll, max_roll, min_pitch, max_pitch, min_yaw, max_yaw, obstacles, method )
digits(5);
global link_length relative_angles target obstacles lb ub R_target grad ra;

quat_target = target(4:7).';
R_target = quat2rotm(quat_target);

lb = [min_roll, min_pitch, min_yaw];
ub = [max_roll, max_pitch, max_yaw];

%% run with gradient

initdraw

relative_angles = zeros(size(link_length,1), 3);
for j = 1 : size(link_length, 1)
    roll = rand() * (max_roll(j) - min_roll(j))  + min_roll(j);
    pitch = rand() * (max_pitch(j) - min_pitch(j)) + min_pitch(j);
    yaw = rand() * (max_yaw(j) - min_yaw(j)) + min_yaw(j);
    relative_angles(j , :) = [roll, pitch, yaw];
end
relative_angles = relative_angles(:).';


if (size(link_length,1) ~= 3 && method == "trust-region-reflective")
    disp("computing gradient...");
    ra = sym('ra', size(relative_angles));
    s = pure_criterion(ra);
    grad = gradient(s, ra);
    disp("done.");
    %  matlabFunction(grad, 'File', 'grad_fn', 'Vars', {ra});
end

running = 1;
while running
    try
        if (method == "sqp")
            options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');
        elseif (method == "interior-point")
            options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'interior-point');
        elseif (method == "active-set")
            options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'active-set');
        elseif (method == "trust-region-reflective")
            options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'trust-region-reflective', 'SpecifyObjectiveGradient', true);
        end

        if (method == "trust-region-reflective")
            [answer,fval,exitflag]=fmincon(@criterion, relative_angles, [],[],[],[],lb,ub,[],options);
        end
        if (method == "sqp" || method == "interior-point" || method == "active-set")
            [answer,fval,exitflag]=fmincon(@criterion, relative_angles, [],[],[],[],lb,ub,@constraints,options);
        end

        running = 0;
    catch
        disp('Division by zero. Rerun.');
        relative_angles = zeros(size(link_length,1), 3);
        for j = 1 : size(link_length, 1)
            roll = rand() * (max_roll(j) - min_roll(j))  + min_roll(j);
            pitch = rand() * (max_pitch(j) - min_pitch(j)) + min_pitch(j);
            yaw = rand() * (max_yaw(j) - min_yaw(j)) + min_yaw(j);
            relative_angles(j , :) = [roll, pitch, yaw];
        end
        relative_angles = relative_angles(:).';
    
    end

end

%% run with cmaes

if (method == "cmaes")
    main_cmaes;
    answer = BestSol.Position;
end

update_draw(answer);


a = reshape(answer, [], 3);
r = a(:, 1);
p = a(:, 2);
y = a(:, 3);

end