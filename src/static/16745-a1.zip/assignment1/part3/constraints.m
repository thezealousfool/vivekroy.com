function [ineq_violations,eq_violations]=constraints(as)
% as: relative_angles

% can add more soft constraints here

global obstacles
 
ps = fk( as);   % ps: position of joints including [0,0,0]
pos = ps(size(ps, 1), :);   % pos: end effactor position

eq_violations = [];
ineq_violations=[];

for j = 1 : size(obstacles, 1)
    o = obstacles(j, 1:3);  % obstacle position
    r = obstacles(j, 4);    % obstacle radius
    for i = 1 : size(ps, 1) - 1
        % compute the shortest distance from each link to the obstacle
        p1 = ps(i, :);
        p2 = ps(i+1, :);
        vec_link = p2 - p1;
        vec_o = o - p1;
        t = dot(vec_link, vec_o) / norm(vec_link) / norm(vec_link);
        if t < 0
            distance = norm(o - p1);
        elseif t > 1
            distance = norm(o - p2);
        else
            distance = norm(p1 + vec_link * t - o);
        end
        
        ineq_violations(size(ineq_violations,2)+1) = -(distance - (r * 1.05));   % distance - r >= 0
    end
end



end

