function score = pure_criterion(relative_angles)
% criterion without gradient

   global target lb ub R_target
    
    score = 0;
    
    [ps, R] = fk(relative_angles);
    
    p = ps(size(ps, 1), :).';    % position of end effector
    pos_target = target(1:3);
    score = score + ( p - pos_target ).' * (p - pos_target );      % close to the target
    
    unit_vec = [1, 0, 0].';
    quat_diff = R * unit_vec - R_target * unit_vec;
    score = score + 0.1 * (quat_diff.' * quat_diff);
    
    relative_angles = reshape(relative_angles, [], 3);
    score = score + 1e-3 * sum(sum(1./ (relative_angles - lb).^(2)));
    score = score + 1e-3 * sum(sum(1./ (relative_angles - ub).^(2)));
   
    pause(0.0000001);
    
end
