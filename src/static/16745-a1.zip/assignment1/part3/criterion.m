function [score, g] = criterion(relative_angles)
% criterion with gradient
digits(5);

    global target link_length 
    global hess grad ra
    
    score = pure_criterion(relative_angles);
    
    if (size(link_length,1) == 3) 
        g = grad_fn(relative_angles);
    else
        relative_angles = relative_angles + (relative_angles == 0) * 1e-8;
        g =double(vpa(subs(grad, ra, relative_angles)));
    end
end